({

    onInit: function (component, event, helper) {
    },

    loadDetails: function (component, event, helper) {
        helper.loadOrders(component,event);
    }
})