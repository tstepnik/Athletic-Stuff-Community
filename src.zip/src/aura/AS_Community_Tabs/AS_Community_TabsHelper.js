/**
 * Created by tomas on 23.11.2020.
 */
({

    redirectToSite: function (component, urlAddress) {
        component.find("redirectCmp").redirectToSite(urlAddress);
    }

})