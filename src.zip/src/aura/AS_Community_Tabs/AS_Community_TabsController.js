/**
 * Created by tomas on 23.11.2020.
 */
({

    toHome: function (component, event, helper) {
        helper.redirectToSite(component, "/as");
    }
})