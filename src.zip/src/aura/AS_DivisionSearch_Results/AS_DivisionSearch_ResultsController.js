({
    handleEvent: function(component, event, helper) {
        helper.handleEvent(component, event);
    },

    tableRowClicked: function(component, event, helper) {
        helper.tableRowClicked(component, event);
    },
    handleDeleteEvent: function(component, event, helper) {
        helper.handleDeleteEvent(component, event);
    }
});