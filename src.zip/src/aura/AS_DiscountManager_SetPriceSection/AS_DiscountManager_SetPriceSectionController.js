({
    onInit: function (component, event, helper) {
        helper.onInit(component, event);
    },

    clickCurrencyButton: function (component, event, helper) {
        helper.clickCButton(component);
    },
    clickPercentButton: function (component, event, helper) {
        helper.clickPercentButton(component);
    },
    setEventWithDiscountInfo: function (component, event, helper) {
        helper.setEventWithDiscountInfo(component, event);
    },

    sendHandleModalEvent: function (component, event, helper) {
        helper.sendHandleModalEvent(component);
    }
})