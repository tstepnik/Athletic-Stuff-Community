/**
 * Created by tomas on 02.12.2020.
 */
({
    onInit: function (component, event, helper) {
        helper.countSum(component,event);
    }
})