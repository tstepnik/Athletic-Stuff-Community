/**
 * Created by tomas on 09.12.2020.
 */
({

    onInit: function (component, event, helper) {
        helper.doInit(component, event);
    },
    tableRowClicked: function (component, event, helper) {
        helper.tableRowClicked(component,event);
    }
})