({
    init : function(component, event, helper){
        console.log('123')
        helper.init(component, event, helper);
    }
})