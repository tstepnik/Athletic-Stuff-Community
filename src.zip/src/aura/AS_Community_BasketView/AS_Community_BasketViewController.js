({
    onInit: function (component,event,helper) {
        helper.getOpportunityProducts(component,event,helper);
    },

    handleEvent: function (component, event, helper) {
        helper.handleEvent(component,event);
    }
})