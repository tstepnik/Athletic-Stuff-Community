/**
 * Created by tomas on 26.11.2020.
 */
({
    onInit: function (component,event,helper) {
        helper.getOpportunityProducts(component,event,helper);
    }
})