({
    init : function(component, event, helper) {
        helper.init(component, event, helper);
    },
    onGetPreviousPage : function(component, event, helper) {
        helper.getPreviousPage(component, event, helper);
    },
    onGetNextPage : function(component, event, helper) {
        helper.getNextPage(component, event, helper);
    },
    onGetFirstPageReviews : function(component, event, helper) {
        helper.getFirstPage(component, event, helper);
    }
})