({
    doInit: function (component, event, helper) {
        helper.init(component, event, helper);
    },
    onSetMainPicture: function (component, event, helper) {
        helper.setMainPicture(component, event, helper);
    },
    onChangePublish : function (component, event, helper) {
        helper.changePublish(component, event, helper);
    }
})