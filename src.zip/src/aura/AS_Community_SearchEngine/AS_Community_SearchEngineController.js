
({

    redirect: function(component, event, helper){
        helper.searchOperations(component,event,helper);


    }
})