({
    onInit : function (component, event, helper) {
        helper.Init(component, event, helper);
    }
})