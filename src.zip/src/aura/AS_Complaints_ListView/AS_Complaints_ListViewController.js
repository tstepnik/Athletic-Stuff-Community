/**
 * Created by tomas on 07.12.2020.
 */
({

    onInit: function (component, event, helper) {
        console.log('wchodzi do controllera');
        helper.doInit(component,event);
        console.log('wychodzi do controllera');
    }
})