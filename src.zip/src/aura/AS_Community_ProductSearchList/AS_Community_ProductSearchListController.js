/**
 * Created by tomas on 23.11.2020.
 */
({

    doInit: function (component, event, helper) {
        helper.loadProducts(component);
    }


})