({
    search: function(component, event, helper) {
        helper.search(component);
    },

    clear: function(component, event, helper) {
        helper.clear(component);
    },
})